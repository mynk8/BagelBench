# Artemis Android QA dataset, v1 draft

## Purpose

This dataset evaluates whether an Android agent can inspect an app and return a supported `PASS`, `FAIL`, or `INCONCLUSIVE` verdict. It adapts AndroidWorld task parameters and state evaluators into paired correct/faulty inspection tasks. It is not a general Android bug corpus and is not an OSWorld-runner plugin.

## Current contents

| Item | Count/status |
|---|---:|
| AndroidWorld task templates | 3 (`ExpenseAddSingle`, `SimpleCalendarAddOneEvent`, `RecipeAddSingleRecipe`) |
| Parameterized cases | 30 |
| Paired variants | 30 control + 30 fault |
| Scheduled task records | 60 |
| Apps | 3 |
| Oracle | Exact target-field predicate plus preservation of preexisting rows |
| Device-admitted cases | 0 in this export; must be measured on the pinned emulator before benchmark scoring |

The 60 records in `exports/osworld_android_qa_v1.jsonl` are **specifications**. They do not contain observed agent results or proof that each fault is visible on screen. Each record therefore says `specification_only_not_device_validated`, `visibility.status=pending`, and `agent_result_status=not_collected`.

The fault variants currently use target deletion, value change, date shift, or text truncation. The paired trials share a prompt and generated task parameters. Variant and oracle labels are evaluator metadata and must not be placed in actor or Checker context.

## Relationship to AndroidWorld and OSWorld

AndroidWorld supplies the source task templates, seeded parameters, app setup patterns, and task success evaluators. This v1 reuses the generated target and distractor records and asks the agent to inspect them. The pilot is therefore derived from AndroidWorld **state/task data**. It does not yet reuse a captured navigation-transition dataset; navigation traces are recorded by Artemis during runs and will need their own reviewed expected-transition annotations.

The JSONL uses the recognizable OSWorld task envelope: `task_id`, `instruction`, `source`, `config`, `evaluator`, and `related_apps`. `artemis_qa` carries the paired-verdict fields. It is an interchange profile, not directly executable by OSWorld: environment setup, AndroidWorld seeding, hidden oracle access, and scoring need the Artemis adapters.

## File map

- `pilot_v1.json` — canonical frozen parameters, pairs, and trial schedule.
- `case_catalog.json` — selected AndroidWorld source templates and mutation candidates.
- `families_v1.json` — QA family taxonomy with current coverage status and source candidates.
- `verifier_contracts_v1.json` — machine-readable contracts and implementation status for all nine buckets; only record integrity has an executable pilot verifier.
- `RUNBOOK.md` — execution, human review, scoring, and admission instructions for the current pilot.
- `oracle_inventory/` — static source audit of all 116 registered AndroidWorld task templates, evaluator implementations, and oracle categories.
- `osworld_profile.schema.json` — JSON Schema for exported OSWorld-style records.
- `exports/osworld_android_qa_v1.jsonl` — one OSWorld-style task record per scheduled variant.
- `exports/pilot_v1.csv` and `exports/pilot_v1.jsonl` — compact analysis exports.
- `reference/android-qa-evaluation-method.md` — verifier design, case admission, scoring, and research basis.
- `reference/independent-checks-research.md` — oracle inventory and AndroidWorld source-task mapping.

Regenerate the OSWorld-style profile without calling a model or device:

```sh
python apps/research_ui/scripts/export_osworld_profile.py \
  apps/research_ui/datasets/androidworld/pilot_v1.json \
  --out apps/research_ui/datasets/androidworld/exports/osworld_android_qa_v1.jsonl
```

## Case admission and scoring

A scheduled case is eligible only after the harness confirms reset/setup, correct control truth, fault truth, protected-state invariants, discoverability in the recorded screen/tree, and valid pre/post oracle reads. A setup or oracle failure is an infrastructure exclusion, not an agent `INCONCLUSIVE`.

The expected verdict is `PASS` for control and `FAIL` for a confirmed fault. Score a false PASS only when the independent pre-run oracle establishes the fault and the agent returns PASS. Preserve `INCONCLUSIVE` as abstention. Report false PASS, false FAIL, inconclusive, decisive coverage, paired correctness (control PASS and fault FAIL), protected-state changes, and excluded infrastructure runs separately.

For evidence about misleading success, record app feedback exposure separately from durable state. A screenshot or accessibility tree may establish that a toast was shown; SQLite/provider/file state establishes whether the write persisted. The current v1 cases do not inject deceptive success messages.

## Taxonomy and limits

`families_v1.json` maps nine useful QA families to independent oracles and candidate AndroidWorld workflows. The source audit finds 116 executable `is_successful` evaluators: 109 state/API-backed patterns and 7 UI/activity-state patterns. That demonstrates broad deterministic *outcome-check* infrastructure, not that these tasks are already QA cases or that they cover real bug prevalence. Only record integrity has pilot case specifications. Other families are candidates, not solved buckets:

- AndroidWorld's state evaluators can ground record contents, action effects, and system settings.
- Its normal workflows can seed navigation-path candidates, but they do not provide controlled Back/cancel/navigation defects.
- Its screen-variation wrapper supplies device profiles, not known overlap/clipping defects.
- It does not provide authenticated membership scenarios; those need a local mock service and synthetic accounts.
- False-success needs an app hook or patched APK that separates the success signal from the durable write.

Do not claim a percentage of real app flows from this task count. Report template count, admitted case count, app-flow coverage, bug-symptom coverage, and oracle coverage as separate quantities. The related research and case-construction methods are summarized with primary-source links in `docs/android-qa-evaluation-method.md` and `docs/independent-checks-research.md`; see especially the Android functional bug dataset, MDroid+ fault operators, Stoat/DroidBot transition models, DDLDroid lifecycle faults, Nighthawk visual defect checks, AndroidWorld, and OSWorld.

## Provenance and license

Source task parameters were generated from Google Research AndroidWorld at revision `55ddaf5edc6f6c25673aed343907d5b9dca66f84`. AndroidWorld is Apache-2.0. Retain attribution and the upstream license when redistributing derived task parameters. Artemis-specific prompts, pair IDs, and schema are project additions. The output contains no user data or measured model traces.

## Validation status

This artifact has not passed device-level admission. Before using it for benchmark claims, run each side of every pair after a clean reset, capture pre/post oracle output, check that the visible UI exposes the criterion, and pin APK hashes plus Android image/API/device profile. The `device_profile` field is intentionally marked as required-to-pin at execution.
