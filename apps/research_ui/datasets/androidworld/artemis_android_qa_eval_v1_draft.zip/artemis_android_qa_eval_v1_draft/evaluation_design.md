# Evaluation design and release format

Status: benchmark development specification. The bundled 30 pairs / 60 task records are planned inspection trials, not an admitted benchmark release.

## What we learned from existing benchmark formats

**OSWorld** makes each task a self-contained JSON record with an identifier, natural-language instruction, source, related applications, setup configuration, and evaluator. The evaluator fetches the observed result, compares it with an expected result, and can apply post-run setup before grading. We follow that packaging boundary: one instruction, versioned setup, and an execution-based evaluator per variant. We use an AndroidWorld setup adapter and an Artemis verifier function, so the records are recognizable in shape but are not executable by the OSWorld runner unchanged. [OSWorld task format](https://timothyxxx.github.io/OSWorld/user_guides/task_example_explanation.html), [OSWorld benchmark paper](https://arxiv.org/abs/2404.07972)

**AndroidWorld** gives us the environment side: 116 parameterized tasks across 20 apps, with task initialization, success checking, and teardown. Its reward comes from device state. We reuse task parameters, setup conventions, and state oracle patterns, then change the evaluated question from “did the agent make the target state?” to “did the tester correctly diagnose a known state?” [AndroidWorld paper](https://arxiv.org/abs/2405.14573), [pinned source revision](https://github.com/google-research/android_world/tree/55ddaf5edc6f6c25673aed343907d5b9dca66f84)

**Terminal-Bench** treats a task as an instruction, isolated environment, outcome tests, and a reference solution. Its tests check final state rather than the agent's command sequence. The benchmark reports human review of task correctness and uses oracle / no-op validation to catch broken or trivial tasks. We adopt the useful QA equivalents: test the actual app truth, show that a no-op tester fails to detect fault cases, ensure a correct control is accepted, and review instruction/evaluator agreement. [Terminal-Bench paper](https://arxiv.org/abs/2601.11868), [task contribution and verifier guidance](https://github.com/harbor-framework/terminal-bench/blob/main/CONTRIBUTING.md)

## Benchmark unit

The atomic case is a **matched pair**, not a single prompt:

1. Generate a known app state from a frozen AndroidWorld task and parameter seed.
2. Make a control that satisfies the criterion.
3. Clone that state and apply one declared fault to create the fault variant.
4. Give both variants the same natural-language inspection instruction and allowed observation/action tools.
5. Keep variant, mutation, expected outcome, and oracle data outside the actor and Checker view.
6. Before the agent starts, verify that control truth is true and fault truth is false. Reject the pair if either precondition fails.
7. Review whether the criterion is discoverable in the app. Retain a screenshot and accessibility tree; use human review where UI semantics are ambiguous.
8. After the agent finishes, re-read the oracle and protected state. A changed target is reported as an observed side effect; it does not by itself establish intent.
9. Score agent verdict against pre-run truth. Do not count setup, emulator, provider, or oracle failures as agent `INCONCLUSIVE`.

An app feedback signal is a separate exposure measurement. A screenshot can prove “Saved” appeared; SQLite/provider/file state proves whether the save persisted. The two are paired, not substituted for each other.

### Accessibility and geometry evidence already captured by Artemis

Artemis already captures a screenshot and Android UI hierarchy during perception and persists the parsed hierarchy and OCR beside the screenshot in its local Data Engine. The parsed hierarchy is the agent-facing version: the Android driver filters nodes and may clip bounds for screen interaction. That representation is useful for action and text checks, but it can erase evidence needed to score clipping or off-screen layout faults. Therefore each recorded step now also preserves the raw Android hierarchy XML in step metadata as `raw_accessibility_hierarchy_xml`. This is tied to the exact step rather than only the screenshot hash, since identical screenshots may recur while the hierarchy changes.

Use the raw hierarchy as the deterministic source for node attributes and screen-coordinate rectangles. Use the saved screenshot for visual confirmation. OCR is a fallback for visible text absent from the tree; OmniParser is optional for screenshot-only icons or custom-drawn controls. Neither OCR nor OmniParser should replace the app-state oracle for correctness. A geometry check reports element bounds, viewport clipping fraction, and pairwise overlap; a reviewer labels whether measured overlap actually blocks a target. The agent can continue using the existing filtered tree. Experiments may give the Checker tree, screenshot, or both while the evaluator retains all captured modalities.

## Case record and release layout

The JSONL task record follows OSWorld's core field convention:

```json
{
  "id": "<trial id>",
  "instruction": "<natural-language inspection test>",
  "source": "AndroidWorld revision and source task",
  "related_apps": ["<app>"],
  "config": [
    {"type": "androidworld_initialize_task", "parameters": {"task_name": "...", "seed": 0}},
    {"type": "apply_qa_variant", "parameters": {"variant": "control|fault", "mutation": {}}}
  ],
  "evaluator": {
    "func": "artemis_android_qa_paired_verdict",
    "result": {"type": "androidworld_state_oracle", "read_before_agent": true, "read_after_agent": true},
    "expected": {"criterion_true_before_agent": true, "agent_verdict": "PASS"},
    "options": {"oracle_version": "...", "target_fields": {}, "protected_state": "..."}
  },
  "artemis_qa": {"pair_id": "...", "variant": "control", "family": "..."}
}
```

`config` and `evaluator` are orchestrator-only. The runtime passes `agent_view` plus live device observations to the agent. The expected label must not leak through prompts, logs, environment variables, file paths, UI state, or checker inputs.

Release contents in `artemis_android_qa_eval_v1_draft/`:

- `tasks.jsonl`: one task per scheduled variant in OSWorld-style shape.
- `planned_trials.csv`: filterable schedule of the current 60 planned trials.
- `evaluation_buckets.csv`: family purpose, case patterns, verifier, source material, and current status.
- `verifier_contracts.json` / `.csv`: exact contract IDs, predicates, required artifacts, code pointer, and implementation status. Only record integrity has an executable verifier in this version.
- `androidworld_oracles.csv` / `.jsonl`: static source audit of all 116 registered AndroidWorld templates.
- `schemas/`: JSON schemas for task records, run results, scorer observations, and verifier contracts.
- `RUNBOOK.md`: how to run, review, score, and rebuild the pilot.
- `dataset_card.md`, `evaluation_design.md`, `research_basis.md`, and `README.md`.
- `bundle_manifest.json`: SHA-256 for each packaged file, excluding the manifest and zip itself.

The release has two separate notions of truth: (a) hidden benchmark ground truth, which the scorer needs, and (b) agent-produced verdict/evidence, which the benchmark measures. A run artifact should record model and provider version, system/app/emulator versions, switches, seed, setup/mutation logs, pre/post oracle snapshots, action sequence, model call IDs/responses, screenshots, accessibility trees, costs, exclusions, and checksums. Keep PII and credentials out; synthetic data only.

## Buckets, checks, and case forms

See `evaluation_buckets.csv` and `verifier_contracts.json` for the machine-readable family table and verifier registry. Only `record_integrity.sqlite_exact_preserve.v1` is implemented; the other eight entries specify future contracts and are not scored test buckets yet.

- **Data correctness:** exact field equality, target cardinality, and protected-row invariants. Use missing, near-miss, wrong-date, duplicate, and truncated-text cases.
- **Persistence:** apply an explicit lifecycle boundary and compare canonical state before/after. Use lost write, stale restore, and durable control pairs.
- **Action effects:** assert the intended delta occurred exactly once and unrelated state did not change. Include no-op, wrong-target, partial, duplicate, collateral, and cancel-commits variants.
- **Navigation:** assert screen/activity state transitions and final data state. Cases need an annotated transition contract and a real faulted route/build; normal AndroidWorld workflows alone do not supply navigation defects.
- **Reachability and visual layout:** tree predicates can check presence, enabled/clickable state, viewport bounds, and mathematical rectangle overlap. Screenshot review verifies semantic obstruction, clipping, or missing visual content. Exclude intentional nesting/overlays; preserve ambiguous cases for human adjudication.
- **Presentation consistency:** compare stored values to rendered accessibility/OCR text through explicit locale/format rules.
- **Access control:** assert against a local mock service and synthetic entitlements, separately from UI claims.
- **Success signal truth:** timestamp visible “success” feedback and compare with durable write state.

For geometric overlap, preserve each relevant element's `[left, top, right, bottom]` rectangle and viewport. Compute intersection width/height as `max(0, min(rights) - max(lefts))` and `max(0, min(bottoms) - max(tops))`; report intersection area divided by the smaller element area so a small button mostly covered by a large surface is not diluted. Compute clipped fraction as off-viewport element area divided by element area. Each case freezes its target elements, allowable overlap, and clip threshold. Do not set one universal threshold before measuring benign nesting, touch targets, dialogs, and accessibility bounds; use screenshot review to decide if the measured intersection actually hides content or prevents interaction.

The current task format has case examples for value mismatch, missing row, date shift, and text truncation in the record-integrity family. The other families in `evaluation_buckets.csv` specify their case patterns but do not yet contain admitted task instances.

## Admission rules and quality review

Each case must pass all gates before contributing to results:

1. **Instruction completeness:** every required assertion is stated in the instruction and checked by the verifier; no hidden extra criterion.
2. **Oracle behavior:** the control satisfies the predicate; the fault violates it; the post-run oracle still resolves the result.
3. **Non-triviality:** a no-op or shallow response cannot pass fault cases; a correct control is not spuriously failed.
4. **Reset and replay:** repeat setup from the same seed and compare canonical state hashes.
5. **Discoverability:** the relevant evidence is available through allowed UI; retain screenshot and tree; a reviewer marks ambiguous visibility.
6. **State safety:** check protected records and isolate irreversible/external side effects.
7. **Hidden truth:** prove the actor and Checker only receive the declared agent view.
8. **Review:** two reviewers inspect the instruction, state mutation, oracle alignment, and failure-mode realism; track disagreements and adjudication.

For visual-only labels, report reviewer agreement and preserve raw screenshots. Automated geometry is a reproducible signal, but does not establish that an overlap is harmful without semantic context.

## Scoring

Score each eligible run with the confusion matrix:

| Hidden state truth | Agent verdict | Score label |
|---|---|---|
| Criterion true | PASS | Correct approval |
| Criterion true | FAIL | False FAIL |
| Criterion false | FAIL | Fault detected |
| Criterion false | PASS | False PASS |
| Either known truth | INCONCLUSIVE | Abstention |
| Truth/setup unavailable | Any | Infrastructure exclusion |

Report false PASS, false FAIL, INCONCLUSIVE, decisive coverage, paired correctness (control PASS + fault FAIL), evidence support, fault localization, protected-state changes, extra actions/cost, and infrastructure exclusions. Break down by bucket, app, fault mechanism, model, condition, framing, and device profile. Use paired confidence intervals and paired tests on matched variants; do not treat repeated parameterizations of one template as independent task templates.

## What this package can claim today

The source inventory shows reusable deterministic evaluator patterns across AndroidWorld. The separate pilot has 30 proposed pairs over three SQLite apps. It is still a **draft dataset**: the trials are not device-admitted, visual discoverability is pending, the other buckets are taxonomy and protocol rather than executed cases, and none tests deceptive success feedback yet. Do not publish benchmark scores or coverage percentages from these specifications.

Suggested expansion: qualify the current record-integrity slice, then add file/provider state, lifecycle persistence, no-op/wrong-target effects, selected real transition faults, reviewed layout faults, and finally a patched-app success-toast case. Use the Android functional bug study and Android mutation-testing literature to select plausible fault operators, not to claim prevalence from synthetic mutants. [Android functional bug study](https://doi.org/10.1145/3597926.3598138), [MDroid+](https://doi.org/10.1145/3106237.3106275), [Stoat](https://doi.org/10.1145/3106237.3106298), [DDLDroid](https://doi.org/10.1145/3597926.3598089), [Nighthawk](https://doi.org/10.1109/TSE.2022.3150876)
