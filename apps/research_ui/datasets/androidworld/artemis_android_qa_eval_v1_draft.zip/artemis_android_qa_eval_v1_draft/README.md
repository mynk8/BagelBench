# Artemis Android QA evaluation dataset — v1 draft

This is a reproducible benchmark-development bundle. It is **not yet an admitted or scored benchmark**: the 30 matched pairs / 60 trial records are specifications pending device, oracle, visibility, and reviewer admission.

## Contents

- `tasks.jsonl`: OSWorld-shaped task records, one per control/fault variant.
- `planned_trials.csv`: spreadsheet-ready schedule; outcomes are not collected.
- `evaluation_buckets.csv`: QA classes, case patterns, independent verifier, source material, status, and admission evidence.
- `verifier_contracts.json`: machine-readable verifier contracts and implementation status for all buckets.
- `verifier_contracts.csv`: spreadsheet view of the verifier registry.
- `androidworld_oracles.csv` / `.jsonl`: source audit of every registered AndroidWorld task template.
- `schemas/`: schemas for task records, run results, scorer observations, and verifier contracts; `run_results_template.csv` is the flat results template.
- `evaluation_design.md`: benchmark unit, verifier pipeline, admission criteria, scoring, and release method.
- `research_basis.md`: packaging patterns reviewed from AndroidWorld, OSWorld, and Terminal-Bench.
- `RUNBOOK.md`: pilot execution, artifact handling, admission, and scoring instructions.
- `visual/evaluation-map.html`: overview of the evaluation flow and bucket readiness.
- `data-tables.html`: browser view of the CSV tables for quick inspection.
- `source/`: canonical pilot manifest, selected source-task catalog, and upstream notice.

## Counts and provenance

- 30 generated pair instances and 60 scheduled variants across Calendar, Expense, and Recipe.
- 116 upstream AndroidWorld task templates source-audited at `55ddaf5edc6f6c25673aed343907d5b9dca66f84`.
- Current pilot family: SQLite record integrity only. Candidate buckets are not yet implemented case suites.
- AndroidWorld source license: Apache-2.0; preserve `THIRD_PARTY_NOTICES.md`.

## Pair semantics

Each pair shares the natural-language inspection instruction and frozen parameters. One variant begins with the criterion true; the other applies one declared mutation. The runtime exposes only `agent_view` and live device observations. Setup details, mutation, expected truth, and evaluator fields stay in the harness.

## Regenerate

From the Artemis repository root, run `python apps/research_ui/scripts/package_android_qa.py`. To regenerate the AndroidWorld source inventory, use the AndroidWorld environment: `python apps/research_ui/scripts/audit_androidworld_oracles.py --androidworld-root /path/to/android_world --out-dir apps/research_ui/datasets/androidworld/oracle_inventory`.

See `DATASET_CARD.md` for status and limits. Do not report benchmark scores from the planned records.
